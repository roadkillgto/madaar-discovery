# Mada'ar (مدار) — Al Qua'a Discovery Hub

**Team:** The Fellas  
**Team Members:** Mohamed Elbashir, Mohamed Aymen, Shahmir Khan  
**Hackathon:** Tatweer Hackathon 2026  
**Challenge:** Challenge 4 — Connecting residents to services, opportunities and events  
**Live Website:** https://roadkillgto.github.io/madaar-discovery/  
**Repository:** https://github.com/roadkillgto/madaar-discovery  

---

## Quick Summary

**Mada'ar** is an offline-first Progressive Web App that connects visitors with camel-farm stargazing experiences, local guidance, safety information, and community dark-sky protocols in Al Qua'a, Al Ain.

The core design principle is:

> Digital for visitors. Simple and human for local residents.

Farm owners do not need to use a new app. A community helper can onboard them through WhatsApp, SMS, phone call, or in-person conversation. Visitors load Mada'ar once before leaving the city, then use the app in the desert even with weak or no data signal.

---

## Screenshots

### Normal Mode

<p align="center">
  <img src="assets/screenshot-01-hero-normal.png" alt="Mada'ar home screen with tonight's stargazing verdict and emergency panel" width="49%">
  <img src="assets/screenshot-03-moon-ask-local-normal.png" alt="Moon Cycle Tracker and Ask a Local feature cards" width="49%">
</p>

<p align="center">
  <img src="assets/screenshot-04-listings-normal.png" alt="Astrotourism, farm tour, and safety listing cards" width="49%">
  <img src="assets/screenshot-05-community-board-normal.png" alt="Community Board dark sky protocol listing" width="49%">
</p>

### Night Vision Mode

<p align="center">
  <img src="assets/screenshot-02-hero-night-vision.png" alt="Mada'ar home screen in red night vision mode" width="49%">
  <img src="assets/screenshot-07-moon-ask-local-night-vision.png" alt="Moon Cycle Tracker and Ask a Local in night vision mode" width="49%">
</p>

<p align="center">
  <img src="assets/screenshot-08-listings-night-vision.png" alt="Listing cards in night vision mode" width="49%">
  <img src="assets/screenshot-06-community-board-night-vision.png" alt="Community Board in night vision mode" width="49%">
</p>

---

## Problem

Al Qua'a has two strong community assets:

- Camel farms and local hospitality
- Very dark desert skies for stargazing

But these assets are not connected in a simple, safe, resident-led way.

Visitors may not know:

- Which farms or sites are suitable for stargazing
- Whether a normal car or 4x4 is needed
- When the moon will be too bright for good stargazing
- What safety steps to take before driving into a rural desert area
- How to respect farm owners, animals, and dark-sky rules

Local farm owners may have space, knowledge, and hospitality to offer, but no simple digital presence or booking system.

---

## Target Users

### Primary users

- Camel farm owners
- Local residents and families
- Local youth who can support guiding or visitor coordination
- Community helpers who can onboard hosts

### Secondary users

- Stargazers
- Families
- Students
- Astronomy groups
- UAE residents and tourists visiting Al Qua'a

---

## Solution

Mada'ar is a static, offline-first PWA that helps visitors plan and complete a safe stargazing visit while giving local residents a path to benefit from eco-tourism.

The app includes listings, moon planning, local guidance, safety reminders, emergency numbers, offline support, and night vision mode.

---

## Main Features

| Feature | Purpose |
|---|---|
| Farm and experience listings | Shows local astrotourism, farm tours, safety support, and community notices |
| Road type badges | Tells visitors if a normal car is okay, 4x4 is recommended, or 4x4 is required |
| Moon Cycle Tracker | Calculates moon phase, illumination %, stargazing quality, and upcoming darker nights |
| Is It Dark Yet? | Uses the device clock to show daylight, twilight, or astronomical darkness |
| Ask a Local | Offline keyword-based local FAQ for arrival time, what to bring, car access, and dark-sky etiquette |
| Night Vision Mode | Switches the whole UI to a red palette to protect night-adapted vision |
| Before You Go checklist | Reminds visitors to check weather, fuel, maps, phone charge, and host confirmation |
| WhatsApp + SMS contact | WhatsApp for normal use, SMS fallback when mobile data is weak |
| Community Board | Shows dark-sky lighting protocol for farms during stargazing events |
| Arabic / English toggle | Static language toggle that works offline |
| Emergency panel | Keeps UAE emergency numbers visible at all times |
| Offline-first PWA | Caches the app after first load so it can work without internet |

---

## How It Works

1. A visitor opens the live site before leaving the city.
2. The service worker caches the app for offline use.
3. The visitor checks tonight's stargazing verdict and moon illumination.
4. The visitor reads the Before You Go checklist.
5. The visitor browses listings and checks road type, capacity, and contact options.
6. The visitor asks a local FAQ question if needed.
7. In the desert, the visitor can still view listings, moon data, safety guidance, and SMS contact options without internet.

For farm owners, onboarding stays simple: a community helper collects details through WhatsApp, SMS, phone call, or in-person conversation, then updates the static listing data.

---

## Why Offline-First Matters

Al Qua'a is a rural desert area where mobile data may be inconsistent. A normal live-data app can fail exactly when visitors need it most.

Mada'ar avoids that risk by using:

- Static files
- Local browser calculations
- Service worker caching
- No backend
- No external APIs
- No monthly hosting or API cost

After the first load, the core app can function with zero connectivity.

---

## Architecture

```text
index.html         — Single-page shell, header, panels, language toggle, emergency panel
main.js            — Card rendering, filters, Ask a Local, service worker registration
moon.js            — Moon phase, illumination, quality rating, upcoming dark-night calculation
data.js            — Listings and local guidance content
utils.js           — HTML escaping, SVG helpers, moon disc rendering
config.js          — Category icons, road type labels, category groups
style.css          — Main styling, cards, night vision mode, mobile layout
service-worker.js  — Offline cache-first strategy
manifest.json      — PWA install metadata
README.md          — Project documentation
```

---

## Validation and Evidence

| Test | Method | Result |
|---|---|---|
| Offline browsing | Load on WiFi, enable airplane mode, navigate app | Pass |
| Moon tracker | Compare moon output with known moon data for test dates | Pass, suitable for trip planning |
| SMS fallback | Disable data, click SMS button | Pass, native SMS opens |
| Night vision | Toggle red mode and review full UI | Pass |
| Arabic toggle | Switch language button | Pass |
| Road badges | Check normal car / 4x4 labels | Pass |
| Emergency panel | Scroll page and check visibility | Pass |
| Mobile layout | Test narrow viewport | Pass |

The moon and darkness tools are prototype planning aids. They are designed for visitor guidance, not professional astronomy or safety-critical decisions.

---

## Feasibility

Mada'ar is feasible because it does not require complex infrastructure.

| Requirement | Approach |
|---|---|
| Hosting | GitHub Pages |
| Data | Static `data.js` file |
| Offline use | Service worker cache |
| Contact | WhatsApp and SMS links |
| Moon data | Local JavaScript calculation |
| Local guidance | Static keyword-matched FAQ |
| Maintenance | Community helper can update listings |
| Cost | No backend, no API keys, no recurring server bill |

---

## Pilot Plan

A small pilot can start with:

- 3 to 5 farm listings
- 1 community helper
- 1 dark-sky event night
- 1 WhatsApp/SMS onboarding process
- 1 GitHub Pages deployment

The goal of the pilot is to test whether visitors can plan safely and whether local farms see value in being listed.

---

## Financial Plan

| Item | Estimated Cost |
|---|---:|
| GitHub Pages hosting | 0 AED |
| Static PWA development | 0 AED during hackathon |
| Google/WhatsApp/SMS contact flow | 0 AED platform cost |
| Canva or visual assets | 0 AED |
| Basic printed host cards | 20 AED |
| Pilot safety signs | 250 AED |
| Low-light markers | 200 AED |
| Waste bags and cleanup supplies | 100 AED |
| Basic first-aid kit | 150 AED |
| **Lean pilot estimate** | **720 AED** |

Future sustainability options:

- Sponsored astronomy nights
- School and university stargazing trips
- Tourism board or municipality support
- Optional commission only after hosts start earning
- CSR support for rural entrepreneurship

---

## Scalability

To add a new farm or community notice, update one file: `data.js`.

To expand to another rural desert community, fork the repo and replace:

- Listings
- Local guidance
- Map links
- Contact numbers
- Community protocols

No backend redesign is needed.

---

## Rejected Features

| Feature | Why it was rejected |
|---|---|
| AI Ask a Local | Requires internet/backend and breaks offline-first design |
| Live weather API | Would fail without internet |
| External moon API | Local calculation is enough for trip planning |
| Push notifications | Requires backend infrastructure |
| Payments/bookings | Out of scope for an MVP focused on discovery and safety |
| Heavy sky map | Too large and not suitable for a lightweight offline PWA |

---

## How to Run Locally

Because the app uses JavaScript modules and a service worker, use a local server instead of opening `index.html` directly.

```bash
# Option 1: Python local server
python3 -m http.server 8000
```

Then open:

```text
http://localhost:8000
```

Or use VS Code Live Server.

---

## Demo Video

Demo video link: **[ADD DEMO VIDEO LINK HERE]**

Suggested demo flow:

1. Open the live website.
2. Show tonight's stargazing verdict.
3. Toggle Night Vision Mode.
4. Check the Moon Cycle Tracker.
5. Use Ask a Local.
6. Filter experiences.
7. Open WhatsApp/SMS/Map buttons.
8. Show the Community Board.
9. Explain offline-first caching.

---

## Team

**The Fellas**

- Mohamed Elbashir
- Mohamed Aymen
- Shahmir Khan

---

## Final Statement

Mada'ar is not just a tourism website. It is a rural discovery and safety tool that helps Al Qua'a residents connect their camel farms and local knowledge with stargazing visitors.

It is simple to maintain, works offline, avoids recurring costs, and is designed around the real conditions of rural desert travel.
